package com.example.prueba_vt2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import static com.example.prueba_vt2.R.style.AlertDialogCustom;

public class Activity2 extends AppCompatActivity {

    ////CREAMOS UN NUEVO OBJETO DE CLASE BBDD, QUE USAREMOS EN LOS DIFERENTES MÉTODOS////
    BBDD bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        String texto = "Estas en la Activity 2";
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }

    ////MÉTODO PARA LA CREACIÓN////
    public void Crear(View view) {
            bd = new BBDD(this, "BaseDatosPeliculas", null, 1);
        Toast.makeText(this, "BBDD creada con éxito", Toast.LENGTH_SHORT).show();
    }

    ////MÉTODO PARA LA INSERCIÓN DE DATOS EN LA TABLA////
    public void InsertarDatos(View view) {

        ///LLAMADA AL MÉTODO Inserta (de la clase BBDD). SE REALIZA UNA NUEVA INSERCIÓN DE DATOS////
        bd.Inserta("Pulp Fiction", "Quentin Tarantino", 8,  this);
        Toast.makeText(this, "Inserción realizada", Toast.LENGTH_SHORT).show();
    }

    //PARA PODER VER LOS RESULTADOS, LLAMAMOS AL MÉTODO Lee (de la clase BBDD) Y RECURRIMOS AL CURSOR Y AL MÉTODO Mensaje
    public void verTabla(View view) {
       Cursor cursor = bd.Lee();

       ////SI NO HAY REGISTROS, LANZAMOS UN MENSAJE DE ERROR////
       if (cursor.getCount() == 0){
           Mensaje("Error", "No hay datos");
               }

       //DECLARAMOS UN NUEVO BUFFER DE String
       StringBuffer buffer = new StringBuffer();

       ////RECORREMOS EL CURSOR DE REGISTRO EN REGISTRO MEDIANTE EL MÉTODO .moveToNext()////
       while (cursor.moveToNext()){

           ///RECUPERAMOS LOS DATOS ALMACENADOS EN EL CURSOR, ACCEDIENDO A SU ÍNDICE DE POSICIÓN EN LA TABLA///
           buffer.append("ID :" + cursor.getString(0)+"\n");
           buffer.append("Título :" + cursor.getString(1)+"\n");
           buffer.append("Director :" + cursor.getString(2)+"\n");
           buffer.append("ImDB :" + cursor.getString(3)+"\n\n");
       }

        //UNA VEZ TERMINADA LA QUERY, SE MOSTRARÁ EL RESULTADO A TRAVÉS DEL
        // AlertDialog CON EL titulo "RESULTADO DE LA CONSULTA" y EL mensaje (resultado de la consulta)
       Mensaje("RESULTADO DE LA CONSULTA", buffer.toString());
    }

    //ESTE MÉTODO CREA UN NUEVO CUADRO DE DIÁLOGO, QUE MOSTRARÁ LO RECOGIDO EN EL MÉTODO ANTERIOR (verTabla)
    public void Mensaje (String titulo, String mensaje){

                ////CREAMOS UN NUEVO Builder, AL QUE LE PASAMOS LOS PARÁMETROS INDICADOS (titulo y mensaje)////
                ///EN ESTE CASO, EL AlertDialog SE CUSTOMIZARÁ, POR LO QUE EN strings.xml DEBE SER DECLARADO////
                AlertDialog.Builder builder = new AlertDialog.Builder(this, AlertDialogCustom);
                builder.setCancelable(true);
                builder.setTitle(titulo);
                builder.setMessage(mensaje);
                builder.show();

    }

    ///VOLVEMOS A LA ACTIVIDAD PRINCIPAL///
    public void volverAuno(View view) {
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Estás en la Activity 1", Toast.LENGTH_SHORT).show();
        finish();
    }
}

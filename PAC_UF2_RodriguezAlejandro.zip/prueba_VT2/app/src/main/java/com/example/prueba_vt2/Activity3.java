package com.example.prueba_vt2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        String texto = "Estás en la Activity 3";
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();

    }

    ////EL PRIMER MÉTODO IRÁ ASOCIADO AL PRIMER RadioButton: CREAR EL SERVICIO  Y REPRODUCIR////

    public void CrearyReproducir(View view){
        Intent intent = new Intent(this, Servicio.class);
        Toast.makeText(this, "Creando y reproduciendo", Toast.LENGTH_SHORT).show();

        //LE DAMOS EL VALOR 1 EN EL EXTRA, QUE LUEGO SERÁ RECOGIDO Y EVALUADO EN EL BUNDLE///

        intent.putExtra("clave",1);

        //LANZAMOS EL SERVICIO DESEADO///
        startService(intent);
    }

    ////EL SEGUNDO MÉTODO IRÁ ASOCIADO AL SEGUNDO RadioButton: DETENER LA REPRODUCCIÓN////

    public void Detener(View view){
        Intent intent = new Intent(this, Servicio.class);
        Toast.makeText(this, "Deteniendo", Toast.LENGTH_SHORT).show();

        //LE DAMOS EL VALOR 2 EN EL EXTRA, QUE LUEGO SERÁ RECOGIDO Y EVALUADO EN EL BUNDLE///

        intent.putExtra("clave", 2);
        startService(intent);
    }

    ////EL TERCER MÉTODO IRÁ ASOCIADO AL TERCER RadioButton: BLOQUEO DE LA APP////

    public void Sleep(View view){
        Intent intent = new Intent(this, Servicio.class);
        //LE DAMOS EL VALOR 3 EN EL EXTRA, QUE LUEGO SERÁ RECOGIDO Y EVALUADO EN EL BUNDLE///

        intent.putExtra("clave", 3);
        startService(intent);
    }

    ///EL ÚLTIMO MÉTODO NOS DEVUELVE A LA ACTIVIDAD PRINCIPAL
    public void volverAmain(View view) {
        Intent intent = new Intent (Activity3.this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Estás en la Activity 1", Toast.LENGTH_SHORT).show();
        finish();
    }


}
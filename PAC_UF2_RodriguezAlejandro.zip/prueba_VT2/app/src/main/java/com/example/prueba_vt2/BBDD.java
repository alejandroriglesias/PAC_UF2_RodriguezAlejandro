package com.example.prueba_vt2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;
import androidx.annotation.Nullable;


///CREAMOS UNA NUEVA CLASE QUE EXTIENDA DE SQLiteOpenHelper
public class BBDD extends SQLiteOpenHelper {
    public BBDD(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    public static final String TABLE_NAME = "pelicula";


    ///ESPECIFICAMOS LA SENTENCIA DE CREACIÓN DE LA TABLA////
    @Override
    public void onCreate(SQLiteDatabase db) {
        String tabla = "CREATE TABLE " + TABLE_NAME +
                    "(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "titulo TEXT, " + "director TEXT, "
                    + "ImDB INTEGER)";
        db.execSQL(tabla);
    }

    ///EL MÉTODO onUpgrade, EN CASO DE QUE LA TABLA EXISTA, LA BORRARÁ Y CREARÁ UNA NUEVA
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE  IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }

    //EL MÉTODO Inserta CONTIENE LA SENTENCIA DE INSERCIÓN DE DATOS
    public  void Inserta (String titulo, String director, int ImDB, Context context){
        SQLiteDatabase escribe = getWritableDatabase();
        String insert = "INSERT INTO " + TABLE_NAME + "(titulo, director, ImDB) " + "VALUES (\""+titulo+"\", \""+director+"\","+ImDB+")";
        escribe.execSQL(insert);
        Toast.makeText(context, "Inserción realizada", Toast.LENGTH_SHORT).show();
        escribe.close();
    }

    //NECESITAMOS UN OBJETO Cursor, AL QUE LE PASAMOS LA CONSULTA DESEADA, LA CUAL RECORRERÁ
    public Cursor Lee(){
        SQLiteDatabase lee = this.getReadableDatabase();
        Cursor cursor = lee.rawQuery( "SELECT * FROM " + TABLE_NAME, null, null);
        return cursor;
    }

}

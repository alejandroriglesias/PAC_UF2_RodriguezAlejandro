package com.example.prueba_vt2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

////MainActivity CONTENDRÁ LA IMAGEN DE BIENVENIDA Y LOS BOTONES PARA NAVEGAR POR LAS ACTIVIDADES////
 public class MainActivity extends AppCompatActivity {

     ////DECLARAMOS TODO EL CICLO DE VIDA LA APLICACIÓN////
     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
     }
     @Override
     protected void onStart(){

         super.onStart();
     }

     @Override
     protected void onRestart(){

         super.onRestart();
     }

     @Override
     protected void onPause(){

         super.onPause();
     }

     @Override
     protected void onResume(){

         super.onResume();
     }
     @Override
     protected void onStop(){

         super.onStop();
     }

     @Override
     protected void onDestroy(){

         super.onDestroy();
     }


    ////MÉTODO PARA IR A LA ACTIVIDAD 2////
     public void irActivity2(View view) {
        Intent intent = new Intent (MainActivity.this, Activity2.class);
        startActivity(intent);
        finish();
     }

     ////MÉTODO PARA IR A LA ACTIVIDAD 3////
     public void irActivity3(View view) {
         Intent intent = new Intent (MainActivity.this, Activity3.class);
         startActivity(intent);
         finish();
     }

 }
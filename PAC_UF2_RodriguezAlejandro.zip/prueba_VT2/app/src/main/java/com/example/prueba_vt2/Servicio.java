
package com.example.prueba_vt2;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.IBinder;
import androidx.annotation.Nullable;

///ES NECESARIO QUE LA CLASE QUE CREEMOS EXTIENDA DE Service///
public class Servicio extends Service {

    ///DECLARAMOS UN NUEVO OBJETO MediaPlayer///
    private MediaPlayer player;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
            //RECUPERAMOS LOS EXTRAS(es decir, los valores numéricos) DE LOS INTENT, A TRAVÉS DEL KEY (en este caso, int "clave")
            Bundle bundle = intent.getExtras();
            int clave = bundle.getInt("clave");

            //CON EL SWITCH, PODREMOS SELECCIONAR LA OPCIÓN A REALIZAR
            switch (clave){
                //EN EL PRIMER CASO (clave = 1), "CREAMOS" EL REPRODUCTOR Y REPRODUCIMOS EL CONTENIDO
                case 1:
                    if (player != null && player.isPlaying())
                        player.stop();
                    player = MediaPlayer.create(this,R.raw.thor);
                    player.start();
                    break;

                // EN EL CASO DE QUE clave=2, DETENEMOS LA REPRODUCCIÓN DEL SONIDO
                case 2:
                    player.stop();
                    break;

                //SI clave=3, BLOQUEAMOS LA APP DURANTE 15 SEGUNDOS, HACIENDO USO DE
                //Thread.sleep  Y UN BLOQUE TRY-CATCH
                case 3:
                    try {
                        ///LA APP SE BLOQUEARÁ DURANTE 15 SEGUNDOS///
                        Thread.sleep(15000);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    break;
            }

        return super.onStartCommand(intent, flags, startId);
    }

    ///AQUÍ DESTRUIMOS EL SERVICIO (¡¡IMPORTANTE!!), "LIBERANDO" TAMBIÉN EL OBJETO DE MediaPlayer///
    @Override
    public void onDestroy() {
        if (player != null)
            player.release();
        stopSelf();
        super.onDestroy();
    }
}